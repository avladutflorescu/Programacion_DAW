package com.company;

import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un número a descrifrar:");
        int num=sc.nextInt();
        int numeros1=123456789;
        int bumeros2=345678921;


    }
}
