package com.company;
import org.w3c.dom.ranges.Range;

import java.util.Scanner;

public class Ejercicio3 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce una fecha");
        String fecha =sc.next();
        String dia=fecha.substring(0, 2);
        String mes=fecha.substring(3,5);
        String año=fecha.substring(6);


        System.out.println(dia+"/"+mes+"/"+año);
    }
}
