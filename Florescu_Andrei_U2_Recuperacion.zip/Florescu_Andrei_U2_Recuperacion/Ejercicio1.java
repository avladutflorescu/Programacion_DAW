package com.company;

import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca la altura de la priramde (superior a 3)");
        int altura=sc.nextInt();
        while (altura<3){
            System.out.println("Introduzca la altura de la priramde (superior a 3)");
            altura=sc.nextInt();
        }
        for (int i = 0; i <altura ; i++) {
            System.out.println();
            for (int j = 0; j <6+(altura-1)*2 ; j++) {
                if (i==0&&j<altura-1){
                    System.out.print("3");
                }
                if (i == 0 & j >= altura - 1 & j < (altura - 1) + 6) {
                    System.out.print("*");
                } else{ System.out.print("");
            }
                if (i==altura-1){
                    System.out.print("*");
                    if (j<altura&&i==0){
                        System.out.print(" ");
                    }
                }else{
                    System.out.print("");
                }
                if (i%2==0&&i!=0&&i!=altura-1&&j>i){
                    System.out.print("*");
                }
                if (j<i && i!=altura-1){
                    System.out.print(" ");
                }


            }

        }

    }
}
