package com.company;

import java.util.Arrays;

import static com.company.Ejercicio3.invertir;

public class Ejercicio3Invertir {
    public static void main(String[] args) {
        String[] cadena;
        cadena = new String[]{"h", "o","l","a"};
        System.out.println(Arrays.toString(invertir(cadena)));
    }
}

