package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio1 {
    public static int[] mediaVectores(int v1[], int v2[]) {
        int resultado[]=new int [(v1.length+v2.length)];
        for (int i = 0; i < resultado.length; i++) {
            if (i<v1.length&&i<v2.length) {
                resultado[i] = (v1[i] + v2[i]) / 2;
            }
            if (i>=v1.length){
                resultado[i] = v2[i];
            }
            if (i>=v2.length){
                resultado[i] = v1[i];
            }
        }
        return resultado;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el tamaño del vector 1");
        int tam1 = sc.nextInt();
        int v1[] = new int[tam1];
        for (int i = 0; i < tam1; i++) {
            System.out.println("Introduce un valor");
            v1[i] = sc.nextInt();


        }
        System.out.println("Introduce el tamaño del vector 2");
        int tam2 = sc.nextInt();
        int v2[] = new int[tam2];
        for (int i = 0; i < tam2; i++) {
            System.out.println("Introduce un valor");
            v2[i] = sc.nextInt();


        }
        System.out.println(Arrays.toString(v1));
        System.out.println(Arrays.toString(v2));
        System.out.println(Arrays.toString(mediaVectores(v1,v2)));
        System.out.println();
    }

}
