package com.company;

import java.sql.PreparedStatement;
import java.util.Arrays;

import static jdk.javadoc.internal.doclets.toolkit.util.Utils.toUpperCase;

public class Ejercicio3 {
    public static String[] invertir(String cadena[]){
        String resultado[]=new String[cadena.length];
        for (int i = 0; i <resultado.length ; i++) {
            resultado[i]=cadena[cadena.length-1-i];

        }
        return resultado;
    }

    public static String [] desplazarVocales(String cadena[]){

    }
    }