package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class EJercicio2 {
    public static void main(String[] args) {
        String tablero [][]=new String[8][8];
        String letra="abcdefgh";
        for (int i = 0; i <8 ; i++) {
            for (int j = 0; j <8 ; j++) {
                tablero[i][j]= String.valueOf(i+1)+letra.charAt(j);

            }


        }
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce la posicion de ela torre:");
        String posicion=sc.next();
        for (int i = 0; i <8 ; i++) {
            for (int j = 0; j <8 ; j++) {
              if (tablero[i][j].equals(posicion)){
                  System.out.println("Los posibles movimientos son:");
                  System.out.println(tablero[i][0]+", "+tablero[i][1]+", "+tablero[i][2]+", "+tablero[i][3]+", "+tablero[i][4]+", "+tablero[i][5]+", "+tablero[i][6]+", "+tablero[i][7]);
                  System.out.println(tablero[0][j]+", "+tablero[1][j]+", "+tablero[2][j]+", "+tablero[3][j]+", "+tablero[4][j]+", "+tablero[5][j]+", "+tablero[6][j]+", "+tablero[7][j]);
              }
            }
        }

    }
}
