package com.company;

public class Ejercico3DesplazarVocales {
    public static void main(String[] args) {
        
    }
}
